#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	int x = 2;
	char c = 'a';
	float f = 3.4;
	string s1 = "Programming";
	string s2 = "Fundamentals";
	ofstream outfile("data.txt");
	outfile<<x<<c<<f<<s1<<' '<<s2<<endl;
	outfile.close();
	x = -100;
	c = 'z';
	f = 9.99;
	s1 = "a";
	s2 = "e";
	ifstream infile("data.txt");
	infile>>x>>c>>f>>s1>>s2;
	cout<<x<<endl<<c<<endl<<f<<endl<<s1<<endl<<s2<<endl;
	infile.close();
	return 0;
}
